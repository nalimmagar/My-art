function runAnimations() {
  runAnimations_1225();
  runAnimations_1254();
}
export default runAnimations;
function runAnimations_1225() {
  document
    .querySelector("#id-18")
    .addEventListener("mouseenter", func_hover_18_112);

  function func_hover_18_112(e) {
    e.stopPropagation();
    function func_18_112(e) {
      document
        .querySelector("#id-18-container")
        .classList.add("parent-animation-18");
      document.querySelector("#id-18").classList.add("animationClass-18");
      document
        .querySelector(".sign-up-19-0")
        .classList.add("animationClass-19-19-0");
      document.querySelector("#id-19").classList.add("animationClass-19");
      document
        .querySelector("#id-18-container")
        .classList.add("parent-animation-18");
      document.querySelector("#id-18").classList.add("animationClass-18");
      document
        .querySelector(".sign-up-19-0")
        .classList.add("animationClass-19-19-0");
      document.querySelector("#id-19").classList.add("animationClass-19");
      document
        .querySelector("#id-18")
        .removeEventListener("mouseenter", func_hover_18_112);

      document
        .querySelector("#id-18")
        .addEventListener("mouseout", func_exit_18_112);
    }

    function func_exit_18_112(e) {
      e.stopPropagation();
      document
        .querySelector("#id-18-container")
        .classList.add("parent-animation-rev-112");
      document.querySelector("#id-18").classList.add("animationClassBack-112");
      document.querySelector("#id-19").classList.add("animationClassBack-113");
      document
        .querySelector("#id-18-container")
        .classList.add("parent-animation-rev-112");
      document.querySelector("#id-18").classList.add("animationClassBack-112");
      document.querySelector("#id-19").classList.add("animationClassBack-113");
      document
        .querySelector("#id-18")
        .removeEventListener("mouseout", func_exit_18_112);
      setTimeout(() => {
        document
          .querySelector("#id-18-container")
          .classList.remove("parent-animation-18");
        document.querySelector("#id-18").classList.remove("animationClass-18");
        document
          .querySelector(".sign-up-19-0")
          .classList.remove("animationClass-19-19-0");
        document.querySelector("#id-19").classList.remove("animationClass-19");
        document
          .querySelector("#id-18-container")
          .classList.remove("parent-animation-18");
        document.querySelector("#id-18").classList.remove("animationClass-18");
        document
          .querySelector(".sign-up-19-0")
          .classList.remove("animationClass-19-19-0");
        document.querySelector("#id-19").classList.remove("animationClass-19");
        document
          .querySelector("#id-18-container")
          .classList.remove("parent-animation-rev-112");
        document
          .querySelector("#id-18")
          .classList.remove("animationClassBack-112");
        document
          .querySelector("#id-19")
          .classList.remove("animationClassBack-113");
        document
          .querySelector("#id-18-container")
          .classList.remove("parent-animation-rev-112");
        document
          .querySelector("#id-18")
          .classList.remove("animationClassBack-112");
        document
          .querySelector("#id-19")
          .classList.remove("animationClassBack-113");
        document
          .querySelector("#id-18")
          .addEventListener("mouseenter", func_hover_18_112);
      }, 1);
    }
    func_18_112();
  }
}
function runAnimations_1254() {
  document
    .querySelector("#id-18")
    .addEventListener("mouseenter", func_hover_18_112);

  function func_hover_18_112(e) {
    e.stopPropagation();
    function func_18_112(e) {
      document
        .querySelector("#id-18-container")
        .classList.add("parent-animation-18");
      document.querySelector("#id-18").classList.add("animationClass-18");
      document
        .querySelector(".sign-up-19-0")
        .classList.add("animationClass-19-19-0");
      document.querySelector("#id-19").classList.add("animationClass-19");
      document
        .querySelector("#id-18-container")
        .classList.add("parent-animation-18");
      document.querySelector("#id-18").classList.add("animationClass-18");
      document
        .querySelector(".sign-up-19-0")
        .classList.add("animationClass-19-19-0");
      document.querySelector("#id-19").classList.add("animationClass-19");
      document
        .querySelector("#id-18")
        .removeEventListener("mouseenter", func_hover_18_112);

      document
        .querySelector("#id-18")
        .addEventListener("mouseout", func_exit_18_112);
    }

    function func_exit_18_112(e) {
      e.stopPropagation();
      document
        .querySelector("#id-18-container")
        .classList.add("parent-animation-rev-112");
      document.querySelector("#id-18").classList.add("animationClassBack-112");
      document.querySelector("#id-19").classList.add("animationClassBack-113");
      document
        .querySelector("#id-18-container")
        .classList.add("parent-animation-rev-112");
      document.querySelector("#id-18").classList.add("animationClassBack-112");
      document.querySelector("#id-19").classList.add("animationClassBack-113");
      document
        .querySelector("#id-18")
        .removeEventListener("mouseout", func_exit_18_112);
      setTimeout(() => {
        document
          .querySelector("#id-18-container")
          .classList.remove("parent-animation-18");
        document.querySelector("#id-18").classList.remove("animationClass-18");
        document
          .querySelector(".sign-up-19-0")
          .classList.remove("animationClass-19-19-0");
        document.querySelector("#id-19").classList.remove("animationClass-19");
        document
          .querySelector("#id-18-container")
          .classList.remove("parent-animation-18");
        document.querySelector("#id-18").classList.remove("animationClass-18");
        document
          .querySelector(".sign-up-19-0")
          .classList.remove("animationClass-19-19-0");
        document.querySelector("#id-19").classList.remove("animationClass-19");
        document
          .querySelector("#id-18-container")
          .classList.remove("parent-animation-rev-112");
        document
          .querySelector("#id-18")
          .classList.remove("animationClassBack-112");
        document
          .querySelector("#id-19")
          .classList.remove("animationClassBack-113");
        document
          .querySelector("#id-18-container")
          .classList.remove("parent-animation-rev-112");
        document
          .querySelector("#id-18")
          .classList.remove("animationClassBack-112");
        document
          .querySelector("#id-19")
          .classList.remove("animationClassBack-113");
        document
          .querySelector("#id-18")
          .addEventListener("mouseenter", func_hover_18_112);
      }, 1);
    }
    func_18_112();
  }
}
// links object
export const allLinks = {};

// function object
export const allFunctions = {};
